import { NextResponse } from "next/server"
import { GoogleSpreadsheet } from "google-spreadsheet"
import { JWT } from "google-auth-library"

// This function handles the POST request to submit feedback to Google Sheets
export async function POST(request: Request) {
  try {
    // Parse the request body
    const body = await request.json()
    const { overallFeedback, learningValue, followUp, message } = body

    // Create a JWT for Google authentication
    const serviceAccountAuth = new JWT({
      email: process.env.GOOGLE_SERVICE_ACCOUNT_EMAIL,
      key: process.env.GOOGLE_PRIVATE_KEY?.replace(/\\n/g, "\n"),
      scopes: ["https://www.googleapis.com/auth/spreadsheets"],
    })

    // Initialize the Google Spreadsheet
    const doc = new GoogleSpreadsheet(process.env.GOOGLE_SHEET_ID as string, serviceAccountAuth)
    await doc.loadInfo()

    // Get the first sheet
    const sheet = doc.sheetsByIndex[0]

    // Add a new row with the feedback data
    await sheet.addRow({
      timestamp: new Date().toISOString(),
      overallFeedback,
      learningValue,
      followUp: followUp ? "Yes" : "No",
      message,
    })

    // Return a success response
    return NextResponse.json({ success: true })
  } catch (error) {
    console.error("Error submitting feedback:", error)
    return NextResponse.json({ success: false, error: "Failed to submit feedback" }, { status: 500 })
  }
}
