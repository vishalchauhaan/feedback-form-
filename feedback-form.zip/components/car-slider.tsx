"use client"

import { useState, useEffect } from "react"
import { Slider } from "@/components/ui/slider"

interface CarSliderProps {
  value: number
  onChange: (value: number) => void
}

export default function CarSlider({ value, onChange }: CarSliderProps) {
  const [sliderValue, setSliderValue] = useState(value)

  // Update parent component when slider value changes
  useEffect(() => {
    onChange(sliderValue)
  }, [sliderValue, onChange])

  // Handle slider change
  const handleSliderChange = (newValue: number[]) => {
    setSliderValue(newValue[0])
  }

  // Get character expression based on rating
  const getExpression = (rating: number) => {
    if (rating <= 2) return "😞"
    if (rating === 3) return "😐"
    return "😊"
  }

  // Get color based on rating
  const getColor = (rating: number) => {
    if (rating <= 2) return "from-red-400 to-red-500"
    if (rating === 3) return "from-yellow-400 to-yellow-500"
    return "from-green-400 to-green-500"
  }

  return (
    <div className="space-y-8">
      <div className="relative pt-16">
        <Slider value={[sliderValue]} min={1} max={5} step={1} onValueChange={handleSliderChange} className="z-0" />

        {/* Modern Car with character */}
        <div
          className="absolute top-0 transform -translate-x-1/2"
          style={{
            left: `${((sliderValue - 1) / 4) * 100}%`,
            transition: "left 0.3s ease-out",
          }}
        >
          <div className="relative">
            {/* Car body */}
            <div
              className={`w-16 h-8 rounded-xl bg-gradient-to-r ${getColor(sliderValue)} shadow-lg flex items-center justify-center`}
            >
              {/* Car windows */}
              <div className="absolute top-1 left-2 right-2 h-3 bg-sky-100 opacity-70 rounded-t-lg"></div>
              {/* Car lights */}
              <div className="absolute bottom-1 left-0 w-1 h-1 bg-yellow-300 rounded-full"></div>
              <div className="absolute bottom-1 right-0 w-1 h-1 bg-red-500 rounded-full"></div>
            </div>

            {/* Car wheels */}
            <div className="absolute -bottom-3 left-2 w-3 h-3 rounded-full bg-gray-800 border-2 border-gray-300"></div>
            <div className="absolute -bottom-3 right-2 w-3 h-3 rounded-full bg-gray-800 border-2 border-gray-300"></div>

            {/* Expression emoji - positioned above the car */}
            <div className="absolute -top-8 left-1/2 transform -translate-x-1/2 text-2xl">
              {getExpression(sliderValue)}
            </div>
          </div>
        </div>
      </div>

      {/* Rating labels */}
      <div className="flex justify-between text-sm text-gray-500">
        <span>1</span>
        <span>2</span>
        <span>3</span>
        <span>4</span>
        <span>5</span>
      </div>
    </div>
  )
}
