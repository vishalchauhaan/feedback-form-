"use client"

import type React from "react"

import { useState } from "react"
import { Card, CardContent, CardDescription, CardFooter, CardHeader, CardTitle } from "@/components/ui/card"
import { Button } from "@/components/ui/button"
import { Label } from "@/components/ui/label"
import { Textarea } from "@/components/ui/textarea"
import { Switch } from "@/components/ui/switch"
import CarSlider from "@/components/car-slider"
import { CheckCircle } from "lucide-react"

export default function FeedbackForm() {
  const [overallFeedback, setOverallFeedback] = useState(3)
  const [learningValue, setLearningValue] = useState(3)
  const [followUp, setFollowUp] = useState(false)
  const [message, setMessage] = useState("")
  const [submitted, setSubmitted] = useState(false)

  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault()

    try {
      // Send the data to our API route
      const response = await fetch("/api/submit-feedback", {
        method: "POST",
        headers: {
          "Content-Type": "application/json",
        },
        body: JSON.stringify({
          overallFeedback,
          learningValue,
          followUp,
          message,
        }),
      })

      const data = await response.json()

      if (data.success) {
        // Show success message
        setSubmitted(true)

        // Reset form after 3 seconds
        setTimeout(() => {
          setOverallFeedback(3)
          setLearningValue(3)
          setFollowUp(false)
          setMessage("")
          setSubmitted(false)
        }, 3000)
      } else {
        throw new Error(data.error || "Failed to submit feedback")
      }
    } catch (error) {
      console.error("Error:", error)
      alert("Failed to submit feedback. Please try again.")
    }
  }

  if (submitted) {
    return (
      <Card className="w-full">
        <CardContent className="pt-6">
          <div className="flex flex-col items-center justify-center py-12 text-center">
            <CheckCircle className="w-16 h-16 text-green-500 mb-4" />
            <h2 className="text-2xl font-bold text-slate-800 mb-2">Thank you for your feedback!</h2>
            <p className="text-slate-600">Your input helps us improve our Level Up Tuesday sessions.</p>
          </div>
        </CardContent>
      </Card>
    )
  }

  return (
    <form onSubmit={handleSubmit}>
      <div className="space-y-6">
        <Card>
          <CardHeader>
            <CardTitle>Overall Feedback</CardTitle>
            <CardDescription>How would you rate your overall experience?</CardDescription>
          </CardHeader>
          <CardContent>
            <CarSlider value={overallFeedback} onChange={setOverallFeedback} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Session Learning Value</CardTitle>
            <CardDescription>How valuable was the content for your learning?</CardDescription>
          </CardHeader>
          <CardContent>
            <CarSlider value={learningValue} onChange={setLearningValue} />
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Follow-up</CardTitle>
            <CardDescription>Would you like a follow-up message?</CardDescription>
          </CardHeader>
          <CardContent>
            <div className="flex items-center space-x-2">
              <Switch id="follow-up" checked={followUp} onCheckedChange={setFollowUp} />
              <Label htmlFor="follow-up">{followUp ? "Yes" : "No"}</Label>
            </div>
          </CardContent>
        </Card>

        <Card>
          <CardHeader>
            <CardTitle>Message to the Speaker</CardTitle>
            <CardDescription>Share any additional thoughts or feedback</CardDescription>
          </CardHeader>
          <CardContent>
            <Textarea
              placeholder="Your message here..."
              className="min-h-[120px]"
              value={message}
              onChange={(e) => setMessage(e.target.value)}
            />
          </CardContent>
        </Card>

        <Card>
          <CardFooter className="pt-6">
            <Button type="submit" className="w-full">
              Submit Feedback
            </Button>
          </CardFooter>
        </Card>
      </div>
    </form>
  )
}
